import { useParams } from "react-router-dom";
import App from "../App";
import axios from 'axios';
import { useEffect,useState } from "react";


const Mahasiswa = () => {

    const [data, setData] = useState(null);

    const fetchData = async () => {
        const res = await axios.get("https://strapi-rygs.onrender.com/api/prodis");
        console.log(res.data.data[0].attributes.prodi[0]);
        setData(res.data.data[0].attributes.prodi[0]);
    }

    useEffect(() => {
        fetchData()
      }, []);

const obj = useParams();
const NPM = obj.id;
let coba = 0;

const tahunMasuk = "20" + NPM.substring(0,2);
const kodeProdi = NPM.substring(4,6);
const id = +NPM.substring(6,10);


return(
    <div>
        {data?.map((prodi , index) =>(
            <div key={index}>
                {prodi.kode_prodi == kodeProdi ? (
                    <div>
                        {prodi.mahasiswa.map((angkatan, index) => (
                            <div key={index}>
                                {angkatan.tahun_masuk === tahunMasuk ? (
                                    <div key={index}> 
                                      {["pagi", "malam", "cuti"].map((kelas , index) => (
                                        <div key={index}>
                                            {angkatan.data[kelas].lenght !== 0 ? (
                                                <div>
                                                    {angkatan.data[kelas].map((mahasiswa, index) => (
                                                        <div key={index}>
                                                            {mahasiswa.id == id ? (
                                                                <div>
                                                                    <h1><b>Data Mahasiswa</b></h1>
                                                                    <p>NPM : {NPM}</p>
                                                                    <p>Nama : {mahasiswa.nama}</p>
                                                                    <p>Jenis Kelamin : {mahasiswa.jenis_kelamin === "L" ? "Laki - Laki" : mahasiswa.jenis_kelamin === "P" ? "Perempuan" : "Tidak Diketahui"}</p>
                                                                    <p>Alamat : {mahasiswa.alamat}</p>
                                                                    <p>Hobi : {mahasiswa.hobi.join(", ")}</p>
                                                                </div>
                                                            ) : null}
                                                            <div className='opacity-0'>
                                                            {mahasiswa.id == id ? (coba = coba + 1) : null}
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                                ) : ( null )}
                                        </div>
                                      ))}  
                                    </div>
                                    ) : null}
                            </div>
                        ))}
                    </div>
                    ) : null}
            </div>
        ))}
        {coba == 0 ? (
          <div>
          <h1><b>Data Mahasiswa</b></h1>
          <p>Mahasiswa Tidak Terdata</p>
          </div>
          ) : null}
        </div>
    )
}

export default Mahasiswa